/*
* GLisp (c) Georges Brougnard
* Integer
* use bigint.js library
*/

///////////////
// INTERFACE
/////////////////////

/*
*/


/////////////////////
// B I G   I N T E G E R S
// Integer
////////////////////////

	


