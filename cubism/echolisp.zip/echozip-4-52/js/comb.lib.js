/*
Glisp
Lib : comb.lib
Exports : 
	(permutations l)
*/