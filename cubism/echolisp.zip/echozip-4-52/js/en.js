/*
Le-L
	English localisation
*/


var msgPass = "Move a token or pass (click on both).";
